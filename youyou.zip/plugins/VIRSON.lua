--[[
--@BRWUEN
--@dev_boots
—]]
do

function run(msg, matches)
  return [[ 
اهــ❤️ــلآ بـ💋ـك فـ😘ـي الـ😉ـسـ🙈ـورس

🔵 الاصدار v2
🔴سورس يخلي من الاخطاء
⚫️مدة توقف سورس لاتقل عن 7ساعات

مطور السورس (🇧 🇷 🇼 🇺 🇪 🇳) > @BRWUEN

لمراسله صانع السورس ↶↶↶
▫️ @BRWUEN
▪️ @LBRWUEN_BOT

مدونتنا ( https://brwuen.blogspot.com )

🚧 تابع قناتنا للبوتات ⬇️ 🚧

@dev_boots 🗼 @dev_boots

🚧 تابع قناه لتطوير بوتك ⬆️ 🚧
]]
end

return {
  description = "", 
  usage = "!السورس:",
  patterns = {
    "^السورس$"
  }, 
  run = run 
}

end
